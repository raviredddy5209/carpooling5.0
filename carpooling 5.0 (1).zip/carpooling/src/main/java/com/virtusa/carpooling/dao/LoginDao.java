package com.virtusa.carpooling.dao;

import java.sql.SQLException;

public interface LoginDao {
	
	boolean Validate(int id,String password) throws SQLException;

}
