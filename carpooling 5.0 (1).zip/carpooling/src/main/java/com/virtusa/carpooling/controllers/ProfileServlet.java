package com.virtusa.carpooling.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.virtusa.carpooling.dao.UserAccImpl;
import com.virtusa.carpooling.dao.UserAccountDao;
import com.virtusa.carpooling.models.mainUser;

/**
 * Servlet implementation class ProfileServlet
 */
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProfileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		UserAccountDao dao = new UserAccImpl();
		
		String empid= request.getParameter("empid");
		System.out.println("EmpId: "+empid);
		
		mainUser userAccount = null;
		try {
			System.out.println("In Profile doPost");
			userAccount=dao.getUserById(Integer.parseInt(empid));
			out.println("Out Profile doPost"+userAccount);
			
		} catch (NumberFormatException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(userAccount!=null) {
			System.out.println("In Profile true");
			
			out.println(new Gson().toJson(userAccount));
		}else
	       {
			System.out.println("In Profile false");
	    	   request.getRequestDispatcher("provider.jsp").include(request, response); 
	       }
	}

}
