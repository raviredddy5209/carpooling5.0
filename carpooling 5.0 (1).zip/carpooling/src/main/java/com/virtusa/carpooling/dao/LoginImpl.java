package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.carpooling.helpers.MySQLHelper;

public class LoginImpl implements LoginDao {
	private Connection conn;
	private CallableStatement callable;
	private static Logger logger = Logger.getLogger(LoginImpl.class);
	static {
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public boolean Validate(int empid, String pass) throws SQLException {
		conn = MySQLHelper.getConnection();
		boolean status = false;
		int k;
		try {
			callable = conn.prepareCall("{call validateUser(?,?,?)}");
			callable.setInt(1, empid);
			callable.setString(2, pass);
			callable.registerOutParameter(3, java.sql.Types.INTEGER);// new one
			callable.execute();
			k = callable.getInt(3);
			if (k == empid) {
				status = true;
				logger.info("logged in succefuly");
			}

		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			status = false;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}

		finally {
			conn.close();
		}

		return status;
	}

}
