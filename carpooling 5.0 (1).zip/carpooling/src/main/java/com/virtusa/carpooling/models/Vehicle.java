package com.virtusa.carpooling.models;

public class Vehicle {

	 

    private int noOfSeats;
    private String vehicleNo;
    
    public int getNoOfSeats() {
        return this.noOfSeats;
    }
    public void setNoOfSeats(int noOfSeats) {
        this.noOfSeats = noOfSeats;
    }
    public String getVehicleNo() {
        return this.vehicleNo;
    }
    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }
    
    
}