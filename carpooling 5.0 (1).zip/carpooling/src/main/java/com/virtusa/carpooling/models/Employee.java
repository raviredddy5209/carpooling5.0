package com.virtusa.carpooling.models;

public class Employee {
    
    private int empId;
    private String name;
    private String email;
    private String address;
    private int phoneNo;
    private Role roleId;
    public int getEmpId() {
        return this.empId;
    }
    public void setEmpId(int empId) {
        this.empId = empId;
    }
    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return this.email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAddress() {
        return this.address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public int getPhoneNo() {
        return this.phoneNo;
    }
    public void setPhoneNo(int phoneNo) {
        this.phoneNo = phoneNo;
    }
    public Role getRoleId() {
        return this.roleId;
    }
    public void setRoleId(Role roleId) {
        this.roleId = roleId;
    }
    
    
}