package com.virtusa.carpooling.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.carpooling.dao.LoginDao;
import com.virtusa.carpooling.dao.LoginImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		LoginDao uai = new LoginImpl();

		String userName = request.getParameter("lguserName");
		String password = request.getParameter("lgpassword");
		boolean status = false;
		try {

			try {
				status = uai.Validate(Integer.parseInt(userName), password);
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (NullPointerException e) {
			request.setAttribute("loginError", "credintial can't be empty");
			request.getRequestDispatcher("index.jsp").include(request, response);
		}
		if (status) {

			session.setAttribute("username", userName);
			session.setAttribute("password", password);
			session.setAttribute("loginError", "");
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Login successful');");
			out.println("location='onLoginSuccess.jsp';");
			out.println("</script>");
			

		} else {
			session.setAttribute("loginError", "Username/Password is invalid");
			request.getRequestDispatcher("index.jsp").include(request, response);
		}
	}

}
