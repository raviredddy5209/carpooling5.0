package com.virtusa.carpooling.dao;
import java.sql.SQLException;
import java.util.List;

import com.virtusa.carpooling.models.*;
public interface ScheduleDao {

	boolean addSchedule(Schedule scheduleId) throws SQLException;
	boolean updateSchedule(Schedule scheduleId) throws SQLException;
	boolean deleteSchedule(int scheduleId) throws SQLException;
	boolean cancelRide(int scheduleId) throws SQLException;
	List <Schedule> getUserById(String startingPoint,String endingPoint)  throws SQLException;
    List <Schedule> getUserByEmployeeId(String employeeId)  throws SQLException;
    List <Schedule> getUserByRides(int employeeId) throws SQLException;
    
    
	
	
}
