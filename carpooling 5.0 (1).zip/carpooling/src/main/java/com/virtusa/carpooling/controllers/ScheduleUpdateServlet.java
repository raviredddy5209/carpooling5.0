package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ScheduleUpdateServlet
 */
public class ScheduleUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScheduleUpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("into the servlet");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
        Enumeration<String> enumeration=request.getParameterNames();
        response.setContentType("text/html");
        String name=null;
        Hashtable<String, String> ht=new Hashtable<String,String>();
        while(enumeration.hasMoreElements())
        {
            name=enumeration.nextElement();
            out.println(name+":"+request.getParameter(name)+"<br/>");
            ht.put(name,request.getParameter(name));
            System.out.println(name+":"+request.getParameter(name));
        }
       
}
}
