package com.virtusa.carpooling.dao;

import java.sql.SQLException;

import com.virtusa.carpooling.models.mainUser;

public interface UserAccountDao {

	boolean addUser(mainUser user) throws SQLException;

	boolean updateUser(mainUser user) throws SQLException;

	boolean updateUserPassword(mainUser user) throws SQLException;

	mainUser getUserById(int empid) throws SQLException;

}
