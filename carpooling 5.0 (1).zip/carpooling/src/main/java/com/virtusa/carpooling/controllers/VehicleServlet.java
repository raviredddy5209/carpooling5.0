package com.virtusa.carpooling.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.carpooling.dao.VehicleDao;
import com.virtusa.carpooling.dao.VehicleImpl;

/**
 * Servlet implementation class VehicleServlet
 */
public class VehicleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VehicleServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();

		VehicleDao dao = new VehicleImpl();

		String employeeId = request.getParameter("employeeId");
		String vehicleId = request.getParameter("vehicleId");
		String numberOfSeats = request.getParameter("numberOfSeats");
		boolean status = false;
		try {

			try {
				status = dao.registerVehicle(vehicleId, Integer.parseInt(numberOfSeats), Integer.parseInt(employeeId));
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (NullPointerException e) {
			request.setAttribute("error", "credintial can't be empty");
			request.getRequestDispatcher("ErrorServlet").include(request, response);
			request.getRequestDispatcher("index.jsp").include(request, response);
		}
		if (status) {
			session.setAttribute("vehicleId", vehicleId);
			session.setAttribute("numberOfSeats", numberOfSeats);
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Vehicle added successfully');");
			out.println("location='provide.jsp';");
			out.println("</script>");
		} else {
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Vehicle added failed');");
			out.println("location='provide.jsp';");
			out.println("</script>");

		}
	}

}
