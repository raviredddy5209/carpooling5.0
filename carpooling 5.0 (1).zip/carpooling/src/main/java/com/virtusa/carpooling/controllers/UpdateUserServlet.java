package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.carpooling.dao.UserAccImpl;
import com.virtusa.carpooling.dao.UserAccountDao;
import com.virtusa.carpooling.models.mainUser;

/**
 * Servlet implementation class UpdateUserServlet
 */
public class UpdateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateUserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");// Output type
		PrintWriter out = response.getWriter();
		String name = null;
		Enumeration<String> enumeration = request.getParameterNames(); // receives from index.js
		mainUser user = new mainUser();// Initializing fojo class
		Hashtable<String, String> ht = new Hashtable<String, String>();

		while (enumeration.hasMoreElements()) {
			name = enumeration.nextElement();
			// out.println(name+":"+request.getParameter(name)+"<br/>");
			ht.put(name, request.getParameter(name));
		}
		user.setEmpId(Long.parseLong(ht.get("employeeId")));
		user.setFullName(ht.get("fullname"));
		user.setEmail(ht.get("email"));
		user.setAddress(ht.get("address"));
		user.setPhoneno(Long.parseLong(ht.get("phoneno")));
		UserAccountDao uai = new UserAccImpl();
		boolean status = false;
		try {
			status = uai.updateUser(user); // status returned from UserAccountImpl class
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (status)
			out.println("Record updated successfully");// writes on response
		else
			out.println("Record updated fail");

	}

}
