package com.virtusa.carpooling.dao;

import java.sql.SQLException;

public interface VehicleDao {
	
	boolean registerVehicle(String vechileNumber,int numberOfSeats,int employeeId) throws SQLException;
	  boolean vehicleSeatCount(String vechileNumber,int employeeId) throws SQLException;

}
