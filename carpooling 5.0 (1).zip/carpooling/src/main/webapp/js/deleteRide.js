function removeMe(addmeRequest) {
    var sId = addmeRequest.getAttribute("value");
    alert("Trip cancelled ");
    var xhr=null;
    try
    {
        xhr=new XMLHttpRequest(); //Chrome, safari, firefox
    }
    catch(err)
    {
        try
        {
            xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");
        }
        catch(err)
        {
            console.log("ajax object not created");
        }
    }

 

    xhr.onreadystatechange=function(){
        var response=null;
        if(xhr.readyState==4) //successful response
            {
            response=xhr.responseText;
            alert(response);
            document.getElementById("result").innerHTML=response;
            }
                
    }
    
    //open the connection
    xhr.open('post','RemoveRideServlet',false);
    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    xhr.send("scheduleId="+sId);
    return false;
}