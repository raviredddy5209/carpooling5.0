window.addEventListener('load',function() {
					   
					    	var form=document.getElementById("signupModal");
				            form.addEventListener('submit',function()
				                    {
				            		var password=document.getElementById("ldpassword").value;  
								    var rpassword=document.getElementById("ldrpassword").value;  
								    if(password==rpassword){
				            		alert("the above entered details should be true upto your knowledge and once entered ");
				                    var xhr=null;
				                        try
				                        {
				                            xhr=new XMLHttpRequest(); // Chrome,
																	 // safari,
																	 // firefox
				                        }
				                        catch(err)
				                        {
				                            try
				                            {
				                                xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");// IE
				                            }
				                            catch(err)
				                            {
				                                console.log("ajax object not created");
				                            }
				                        }
				                    
				                        xhr.onreadystatechange=function(){
				                            var response=null;
				                            if(xhr.readyState==4) // successful
																	// response
				                                {
				                                //response=xhr.responseText;
				                                //alert(response);
				                                document.getElementById("results").style.display="block";
				                                //document.getElementById("results").innerHTML=response;
				                                }
				                                    
				                        }
				                       
				                        
				                        // open the connection
				                        xhr.open('post','UserServlet',false); // Userservlet														// will
																				// Initiated
																				// dopost
				                        xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
				                        var employeeId=document.getElementById('employeeId').value;
				                        var fullName=document.getElementById('fullName').value;
				                        var email=document.getElementById('email').value;
				                        var address=document.getElementById('address').value;
				                        var phone=document.getElementById('phoneno').value;
				                        var password=document.getElementById('ldpassword').value;
				                        xhr.send("employeeId="+employeeId+"&fullName="+fullName+"&email="+email+"&address="+address+"&phoneno="+phone+"&password="+password); // send
																																							// to
																																							// response
				                        return false;
				                 
				                    
				                    }
					    else
					    	alert("password one and two must be same!"); 
				                    });


});
