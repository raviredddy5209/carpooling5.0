window.addEventListener('load',function() {
      var form=document.getElementById("createScheduleForm");
            form.addEventListener('submit',function()
                    {
            		alert("the above entered details should be true upto your knowledge and once entered ");
                    var xhr=null;
                        try
                        {
                            xhr=new XMLHttpRequest(); //Chrome, safari, firefox
                        }
                        catch(err)
                        {
                            try
                            {
                                xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");
                            }
                            catch(err)
                            {
                                console.log("ajax object not created");
                            }
                        }
                    
                        xhr.onreadystatechange=function(){
                            var response=null;
                            if(xhr.readyState==4) //successful response
                                {
                                response=xhr.responseText;
                                alert(response);
                                document.getElementById("result").innerHTML=response;
                                }
                                    
                        }
                        
                        //open the connection
                        xhr.open('post','ScheduleServlet',false);
                        xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        
                        var employeeId=document.getElementById('cfemployeeId').value;
                        console.log(document.getElementById('cfemployeeId').value);
                        var startingPoint=document.getElementById('cfstartingPoint').value;
                        var endingPoint=document.getElementById('cfendingPoint').value;
                        var time=document.getElementById('cftime').value;
                        var vehicleId=document.getElementById('cfvehicleId').value;
                     	console.log(document.getElementById('cfvehicleId').value);
                        var numberOfSeats=document.getElementById('cfnumberOfSeats').value;
                        console.log(document.getElementById('cfnumberOfSeats').value);
                   
                        
                        xhr.send("employeeId="+employeeId+"&startingPoint="+startingPoint+"&endingPoint="+endingPoint+"&time="+time+"&vehicleId="+vehicleId+"&numberOfSeats="+numberOfSeats);
                        
                        return false;
                    });
                  
              
                    
                    
                    var form=document.getElementById("modifyScheduleForm");
                    form.addEventListener('submit',function()
                            {
                            alert("the above entered details should be true upto your knowledge and once entered ");
                            var xhr=null;
                                try
                                {
                                    xhr=new XMLHttpRequest(); //Chrome, safari, firefox
                                }
                                catch(err)
                                {
                                    try
                                    {
                                        xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");
                                    }
                                    catch(err)
                                    {
                                        console.log("ajax object not created");
                                    }
                                }
                           
                                xhr.onreadystatechange=function(){
                                    var response=null;
                                    if(xhr.readyState==4) //successful response
                                        {
                                        response=xhr.responseText;
                                        alert(response);
                                        document.getElementById("result").innerHTML=response;
                                        }
                                }
                               
                                //open the connection
                                xhr.open('post','ScheduleServlet',false);
                                xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                                var employeeId=document.getElementById('employeeId').value;
                                var startingPoint=document.getElementById('startingPoint').value;
                                var endingPoint=document.getElementById('endingPoint').value;
                                var time=document.getElementById('time').value;
                                var vehicleId=document.getElementById('vehicleId').value;
                                var numberOfSeats=document.getElementById('numberOfSeats').value;
                               
                                xhr.send("employeeId="+employeeId+"&startingPoint="+startingPoint+"&endingPoint="+endingPoint+"&time="+time+"&vehicleId="+vehicleId+"&numberOfSeats="+numberOfSeats);
                                return false;
                            });
                    
                    
                    
                    
                    
                    
                    var form=document.getElementById("deleteScheduleForm");
                    form.addEventListener('submit',function()
                            {
                            var xhr=null;
                                try
                                {
                                    xhr=new XMLHttpRequest(); //Chrome, safari, firefox
                                }
                                catch(err)
                                {
                                    try
                                    {
                                        xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");
                                    }
                                    catch(err)
                                    {
                                        console.log("ajax object not created");
                                    }
                                }
                           
                                xhr.onreadystatechange=function(){
                                    var response=null;
                                    if(xhr.readyState==4) //successful response
                                        {
                                        response=xhr.responseText;
                                        alert(response);
                                        document.getElementById("result").innerHTML=response;
                                        }
                                }
                               
                                //open the connection
                                xhr.open('post','DeleteScheduleServlet',false);
                                xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                                var schId=document.getElementById('dScheduleId').value;
                                console.log(document.getElementById('dScheduleId').value);
                                xhr.send("scheduleId="+schId);
                                return false;
                            });  
                    
                    
                    
                    
               return false;     
                    
                    
})