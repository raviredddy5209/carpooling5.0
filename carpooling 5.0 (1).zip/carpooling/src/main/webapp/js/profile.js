function enableField(elements, Modify) {

	for (var i = 0, element; element = elements[i++];) {

		if (Modify && element.type === "text") {

			element.removeAttribute("disabled")

		}

		else if (!Modify && element.type === "text") {

			element.setAttribute("disabled", "disabled")

		}

		else if (element.type === "button") {

			if (element.style.visibility === "hidden") {

				element.style.visibility = "visible";

			}

			else if (element.style.visibility === "visible") {

				element.style.visibility = "hidden";

			}

		}

	}

}
