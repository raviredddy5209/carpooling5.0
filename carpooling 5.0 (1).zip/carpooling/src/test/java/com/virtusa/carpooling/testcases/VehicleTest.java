package com.virtusa.carpooling.testcases;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.regex.Pattern;

import org.hamcrest.Matchers;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.virtusa.carpooling.models.Vehicle;

@RunWith(value=Parameterized.class)

public class VehicleTest {
	

	private static Vehicle vehicle;	
	
	  @Parameter(value = 0)
	  public String vehicleNo;
	  @Parameters
		public static Collection getTestParameters() {
			return Arrays.asList(new Object[][] {{"TN76-7M"},{"TN23 7D"}});
		}
	@BeforeClass
	public static void createInstance()
	{
		vehicle=new Vehicle ();
	}

	@Before
	public void initializeUser()
	{
		vehicle.setVehicleNo(vehicleNo);
	}
	

	@AfterClass
	public static void deleteInstance()
	{
		vehicle=null;
	}
	@Test
	public void testVehicleNo()
	{
		//To check if employeeId is not null
		assertThat(vehicle.getVehicleNo(),is(notNullValue()));
	}
	
	@Test
	public void testVehicleNoPattern()
	{
		//To check if fullName is not null
		assertEquals(true, vehicle.getVehicleNo().matches("^([A-Z]{2}\\s?(\\d{2})?(-)?([A-Z]{1}|\\d{1})?([A-Z]{1}|\\d{1}))$"));
		
	}

}
