package com.virtusa.carpooling.testcases;

import static org.junit.Assert.*;

import java.sql.Time;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyIterableOf;
import static org.hamcrest.core.Is.*;
import org.hamcrest.Matchers;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import com.virtusa.carpooling.models.Schedule;
@RunWith(value=Parameterized.class)

public class ScheduleTest {
	
	private static Schedule schedule;	
	
	  @Parameter(value = 0)
	  public String startingPoint;
	  @Parameter(value = 1)
	  public String endingPoint;
	  @Parameters
		public static Collection getTestParameters() {
			return Arrays.asList(new Object[][] {{"Mylapore","Navalur"}
			,{"Sholinganallur","Sholinganallur"}});
		}
	@BeforeClass
	public static void createInstance()
	{
		schedule=new Schedule  ();
	}

	@Before
	public void initializeSchedule()
	{
		schedule.setStartingPoint(startingPoint);
		schedule.setEndingPoint(endingPoint);
	}

	@AfterClass
	public static void deleteInstance()
	{
		schedule=null;
	}
		@Test
		public void testStartingPoint()
		{
			//To check if fullName is not null
			assertThat(schedule.getStartingPoint(),is(notNullValue()));
		}
		@Test
		public void testEndingPoint()
		{
			//To check if fullName is not null
			assertThat(schedule.getEndingPoint(),is(notNullValue()));
		}
		@Test
		public void testStartingEndingNotSame()
		{
			//To check if password and fullname are not same
			assertNotSame(schedule.getStartingPoint(),schedule.getEndingPoint());
		}
	}


