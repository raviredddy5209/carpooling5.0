package com.virtusa.carpooling.testcases;

import static com.jcabi.matchers.RegexMatchers.matchesPattern;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import java.util.regex.Pattern;

import org.hamcrest.Matchers;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.virtusa.carpooling.dao.UserAccImpl;
import com.virtusa.carpooling.dao.UserAccountDao;
import com.virtusa.carpooling.models.mainUser ;

@RunWith(value=Parameterized.class)
public class SignUpTest {
	
	private static mainUser  mainuser;	
	
	  @Parameter(value = 0)
	  public long empId;
	  @Parameter(value = 1)
	  public String fullName;
	  @Parameter(value = 2)
	  public String email;
	  @Parameter(value =3)
	  public  String address;
      @Parameter(value = 4)
	  public String password;
//      @Parameter(value = 5)
//      public int role_id;
  
	  
	  
	@Parameters
	public static Collection getTestParameters() {
		return Arrays.asList(new Object[][] {{8062939,"Sruthi Ramesh","sruthi@virtusa.com","Chennai","@T6sruI"}
		,{8057262,null,"navin@virtusa.com","Chennai","$gdT765"},
		{8062902,"Ha4rini","gharini@virtusa.com","Chennai","Harini"}});
	}
@BeforeClass
public static void createInstance()
{
	mainuser=new mainUser ();
}

@Before
public void initializeUser()
{
	mainuser.setEmpId(empId);
	mainuser.setFullName(fullName);
	mainuser.setEmail(email);
	mainuser.setAddress(address);
	mainuser.setPassword(password);
	//mainuser.setRole_id(role_id);
}

@AfterClass
public static void deleteInstance()
{
	mainuser=null;
}
@Test
public void testEmpId()
{
	//To check if employeeId is not null
	assertThat(mainuser.getEmpId(),is(notNullValue()));
}


@Test
public void testFullName()
{
	//To check if fullName is not null
	assertThat(mainuser.getFullName(),is(notNullValue()));
}
@Test
public void testFullNamePattern()
{
	//To check if fullName is not null
	assertEquals(true, mainuser.getPassword().matches("[a-zA-Z ]*$"));
	
}


@Test
public void testEmail()
{
	//To check if fullName is not null
	assertThat(mainuser.getEmail(),is(notNullValue()));
}

@Test
public void testPassword()
{
	//To check if fullName is not null
	assertThat(mainuser.getPassword(),is(notNullValue()));
}


@Test
public void testPasswordNotSame()
{
	//To check if password and fullname are not same
	assertNotSame(mainuser.getPassword(),mainuser.getFullName());
}

@Test
public void testPasswordPattern()
{
	//To check if password and fullname are not same
	assertEquals(true, mainuser.getPassword().matches("(?=^.{6,15}$)(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&amp;*()_+}{&quot;&quot;:;'?/&gt;.&lt;,]).*$"));
	//assertThat(mainuser.getPassword(), matchesPattern("[a-z]+"));
}



@Test
public void testAddUser() throws SQLException {
	UserAccountDao dao=new UserAccImpl();
	assertEquals(true,dao.addUser(mainuser) );
}


//@Test
//public void testEmpIdPattern()
//{
//	//To check if employeeId is not null
//	//assertThat(mainuser.getEmpId(),matchesPattern("^[0-9]+$"));
//	String numregex="^[0-9]+$";
//	String id=mainuser.getEmpId()+"";
//	assertEquals(true, id.matches(numregex));
//	//assertThat(mainuser.getEmpId(), matchesPattern());
//}
}