DELIMITER $$

DROP PROCEDURE IF EXISTS modifySchedule $$
create procedure modifySchedule(in p_scheduleId integer(20),
in p_startingPoint varchar(30),
in p_endingPoint varchar(50),
in p_startTime time,
in p_vehicleId varchar(30),
in p_numberOfSeats integer(20))
BEGIN

update schedule set startingPoint=p_startingPoint, endingPoint=p_endingPoint, startTime=p_startTime, numberOfSeats=p_numberOfSeats
where scheduleId=p_scheduleId;
END $$
DELIMITER ;
