DELIMITER $$

DROP PROCEDURE IF EXISTS addVehicle $$
create procedure addVehicle (
in p_vehicleId varchar(20),
in p_numberOfSeats integer(20),
in p_employeeId integer(20)
)


BEGIN
DECLARE

p_availableSeats integer(20);

SET p_availableSeats=p_numberOfSeats;

insert into vehicle values(p_vehicleId, p_numberOfSeats,p_employeeId,p_availableSeats);

update user set roleId=1,vehicleId=p_vehicleId where employeeId=p_employeeId;
 
END $$
DELIMITER ;
