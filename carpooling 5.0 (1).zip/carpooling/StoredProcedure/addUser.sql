DELIMITER $$

DROP PROCEDURE IF EXISTS addUser $$
create procedure addUser(in p_employeeId int(20)
,in p_fullName varchar(30),
in p_email varchar(50),
in p_address varchar(50),
in p_phoneno bigint(20),
in p_password varchar(30),
in p_roleId tinyint(1))

BEGIN

insert into user(employeeId,fullName,email,address,phoneno,password,roleId) values(p_employeeId,p_fullName,p_email,p_address,p_phoneno,SHA1(p_password),p_roleId);

END $$
DELIMITER ;
