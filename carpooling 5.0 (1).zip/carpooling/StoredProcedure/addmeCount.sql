DELIMITER $$

 

 

 



DROP PROCEDURE IF EXISTS addmeCount $$



create procedure addmeCount(in p_vehicleId varchar(30),in p_employeeId int(20))

 


BEGIN

 

update vehicle v set availableSeats=availableSeats-1 where vehicleId=p_vehicleId;

 

update trip set noOfPassengers=noOfPassengers+1 where vehicleId=p_vehicleId;


insert into riders values ((select tripId from trip where vehicleId=p_vehicleId),p_employeeId);
END $$

 


DELIMITER ;