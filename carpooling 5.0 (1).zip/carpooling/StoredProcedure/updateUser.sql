DELIMITER $$

DROP PROCEDURE IF EXISTS updateUser $$
create procedure updateUser(in p_employeeId int(20),
in p_fullName varchar(30),
in p_email varchar(50),
in p_address varchar(50),
in p_phoneno bigint(20))

BEGIN

update user set fullName=p_fullname,email=p_email,address=p_address,phoneno=p_phoneno where employeeId=p_employeeId;

END $$
DELIMITER ;
